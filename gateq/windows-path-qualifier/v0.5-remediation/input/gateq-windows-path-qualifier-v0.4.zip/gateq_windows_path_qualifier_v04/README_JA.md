# Gate Q Windows Path Qualifier v0.4

## 状態

**Fresh Re-Audit待ちのread-only candidateです。Windowsホストではまだ実行しないでください。**

v0.3 Fresh Independent Static Audit（FAIL: CRITICAL 0 / MAJOR 4 / MINOR 2 / NOTE 2）で指摘されたF-01〜F-08を対象にremediationした版です。

## 用途

Windowsホスト上で、次のread-only compatibility / identity proofを行うためのfreestanding x64 PEです。

- local NTFS root-to-leaf path chain
- `NtOpenFile` + `OBJECT_ATTRIBUTES.RootDirectory` による1 componentずつのparent-relative open
- `FILE_OPEN_REPARSE_POINT`
- `FILE_ID_INFO`
- `FILE_ATTRIBUTE_TAG_INFO`
- 32-bit / 64-bit volume identityのroot binding
- delete-shareを許さないancestor handle retention
- final fileはread-share only
- offline/cloud/virtualized属性のfail-closed reject
- retained final handleからのSHA-256
- chain revalidation

## v0.4 remediation

- 余分なCLI引数、未閉鎖quote、embedded quoteを拒否
- drive letterをASCII英字へ限定
- forward slash、duplicate separator、trailing separatorを拒否
- 128-bit FileId == all-zero を拒否
- rootの32-bit volume serialと64-bit `FILE_ID_INFO.VolumeSerialNumber`を保持し、全node/revalidationで双方を比較
- `OFFLINE`, `VIRTUAL`, `RECALL_ON_OPEN`, `PINNED`, `UNPINNED`, `RECALL_ON_DATA_ACCESS`を拒否
- hash後のfile-pointer reset失敗をfail closed
- PASS JSONにnode別FileId / volume / attributes / reparse tag / typeを追加
- Python 3.13.5と生成toolのabsolute pathをbuild recipeへbinding
- fresh A/B buildを再実行し、xtrace logをbundleへ保存

## CLI

唯一のmode:

`--qualify-paths <kernel-absolute-path> <wslconfig-absolute-path>`

入力pathはcanonicalなdrive-letter absolute pathのみを意図します。例:

`C:\Users\user\TsuchimaruGateA\runs\<run_id>\kernel\bzImage`

## 明示的にしないこと

このPEは以下を実装しません。

- `.wslconfig`書換え
- WSL起動
- `wsl --shutdown`
- WSL restart
- custom kernel activation
- process creation
- PowerShell / cmd / shell evaluation
- Registry/service変更
- ACL/xattr変更
- Host Activation
- Gate A
- Runtime

## 重要な境界

このcandidateは最終Runtime用`WINDOWS_WSL_BOOT_WITNESS_BINDING_V1`ではありません。

Fresh Static Re-Audit PASS後であっても、許可されるのは既承認のread-only Windows Host Qualification laneでの使用だけです。実Windows上の`ntdll.dll`, `wsl.exe`, WSL loader/service, NTFS/NtOpenFile/share semanticsは別途host qualificationでfreeze・検証する必要があります。
