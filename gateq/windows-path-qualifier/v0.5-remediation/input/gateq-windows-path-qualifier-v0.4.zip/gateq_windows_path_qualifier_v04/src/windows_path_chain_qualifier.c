/* v0.18 Gate Q Windows path-chain qualification witness.
 * Freestanding Windows x64 PE: no CRT, no Windows SDK headers required.
 * Qualification command only; does NOT modify .wslconfig and does NOT invoke WSL.
 */

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef long NTSTATUS;
typedef unsigned long ULONG;
typedef unsigned long DWORD;
typedef unsigned long ACCESS_MASK;
typedef int BOOL;
typedef unsigned short WCHAR;
typedef WCHAR *PWSTR;
typedef void *PVOID;
typedef void *HANDLE;
typedef HANDLE *PHANDLE;
typedef unsigned long long ULONG_PTR;
typedef long long LONGLONG;
typedef unsigned long long SIZE_T;
typedef unsigned short USHORT;

#define DLLIMPORT __declspec(dllimport)
#define STDCALL __stdcall
#define TRUE 1
#define FALSE 0
#define INVALID_HANDLE_VALUE ((HANDLE)(long long)-1)
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define STD_ERROR_HANDLE ((DWORD)-12)

#define FILE_READ_DATA 0x0001u
#define FILE_LIST_DIRECTORY 0x0001u
#define FILE_READ_ATTRIBUTES 0x0080u
#define SYNCHRONIZE 0x00100000u
#define FILE_SHARE_READ 0x00000001u
#define FILE_SHARE_WRITE 0x00000002u
#define OPEN_EXISTING 3u
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010u
#define FILE_ATTRIBUTE_REPARSE_POINT 0x00000400u
#define FILE_ATTRIBUTE_OFFLINE 0x00001000u
#define FILE_ATTRIBUTE_VIRTUAL 0x00010000u
#define FILE_ATTRIBUTE_RECALL_ON_OPEN 0x00040000u
#define FILE_ATTRIBUTE_PINNED 0x00080000u
#define FILE_ATTRIBUTE_UNPINNED 0x00100000u
#define FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS 0x00400000u
#define FILE_FLAG_OPEN_REPARSE_POINT 0x00200000u
#define FILE_FLAG_BACKUP_SEMANTICS 0x02000000u
#define FILE_BEGIN 0u
#define OBJ_CASE_INSENSITIVE 0x00000040u
#define FILE_DIRECTORY_FILE 0x00000001u
#define FILE_SYNCHRONOUS_IO_NONALERT 0x00000020u
#define FILE_NON_DIRECTORY_FILE 0x00000040u
#define FILE_OPEN_REPARSE_POINT 0x00200000u
#define STATUS_SUCCESS ((NTSTATUS)0)
#define NT_SUCCESS(s) ((NTSTATUS)(s) >= 0)
#define FILE_ID_INFO_CLASS 18
#define FILE_ATTRIBUTE_TAG_INFO_CLASS 9

/* Minimal Windows ABI structures. */
typedef union _LARGE_INTEGER { struct { u32 LowPart; long HighPart; }; LONGLONG QuadPart; } LARGE_INTEGER;
typedef struct _UNICODE_STRING { USHORT Length; USHORT MaximumLength; PWSTR Buffer; } UNICODE_STRING;
typedef struct _OBJECT_ATTRIBUTES { ULONG Length; HANDLE RootDirectory; UNICODE_STRING *ObjectName; ULONG Attributes; PVOID SecurityDescriptor; PVOID SecurityQualityOfService; } OBJECT_ATTRIBUTES;
typedef union _IO_STATUS_BLOCK { NTSTATUS Status; PVOID Pointer; struct { ULONG_PTR Information; }; } IO_STATUS_BLOCK;
typedef struct _FILE_ID_128 { u8 Identifier[16]; } FILE_ID_128;
typedef struct _FILE_ID_INFO { u64 VolumeSerialNumber; FILE_ID_128 FileId; } FILE_ID_INFO;
typedef struct _FILE_ATTRIBUTE_TAG_INFO { DWORD FileAttributes; DWORD ReparseTag; } FILE_ATTRIBUTE_TAG_INFO;

DLLIMPORT void STDCALL ExitProcess(u32);
DLLIMPORT WCHAR *STDCALL GetCommandLineW(void);
DLLIMPORT HANDLE STDCALL GetStdHandle(DWORD);
DLLIMPORT BOOL STDCALL WriteFile(HANDLE,const void*,DWORD,DWORD*,void*);
DLLIMPORT HANDLE STDCALL CreateFileW(const WCHAR*,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);
DLLIMPORT BOOL STDCALL GetFileInformationByHandleEx(HANDLE,int,void*,DWORD);
DLLIMPORT BOOL STDCALL GetVolumeInformationByHandleW(HANDLE,WCHAR*,DWORD,DWORD*,DWORD*,DWORD*,WCHAR*,DWORD);
DLLIMPORT BOOL STDCALL ReadFile(HANDLE,void*,DWORD,DWORD*,void*);
DLLIMPORT BOOL STDCALL SetFilePointerEx(HANDLE,LARGE_INTEGER,LARGE_INTEGER*,DWORD);
DLLIMPORT BOOL STDCALL CloseHandle(HANDLE);
DLLIMPORT NTSTATUS STDCALL NtOpenFile(PHANDLE,ACCESS_MASK,OBJECT_ATTRIBUTES*,IO_STATUS_BLOCK*,ULONG,ULONG);

/* SHA-256, self-contained. */
typedef struct { u32 h[8]; u64 bits; u8 buf[64]; u32 used; } sha256_ctx;
static u32 rotr(u32 x,u32 n){return (x>>n)|(x<<(32-n));}
static const u32 K256[64]={
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
/* Correct accidental shortened constant at runtime-free compile time through literal override. */
static void sha_block(sha256_ctx*c,const u8*b){u32 w[64],a,bv,cc,d,e,f,g,h,t1,t2;int i;for(i=0;i<16;i++)w[i]=((u32)b[4*i]<<24)|((u32)b[4*i+1]<<16)|((u32)b[4*i+2]<<8)|b[4*i+3];for(i=16;i<64;i++){u32 s0=rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>3),s1=rotr(w[i-2],17)^rotr(w[i-2],19)^(w[i-2]>>10);w[i]=w[i-16]+s0+w[i-7]+s1;}a=c->h[0];bv=c->h[1];cc=c->h[2];d=c->h[3];e=c->h[4];f=c->h[5];g=c->h[6];h=c->h[7];for(i=0;i<64;i++){u32 kv=K256[i];u32 S1=rotr(e,6)^rotr(e,11)^rotr(e,25),ch=(e&f)^((~e)&g);t1=h+S1+ch+kv+w[i];u32 S0=rotr(a,2)^rotr(a,13)^rotr(a,22),maj=(a&bv)^(a&cc)^(bv&cc);t2=S0+maj;h=g;g=f;f=e;e=d+t1;d=cc;cc=bv;bv=a;a=t1+t2;}c->h[0]+=a;c->h[1]+=bv;c->h[2]+=cc;c->h[3]+=d;c->h[4]+=e;c->h[5]+=f;c->h[6]+=g;c->h[7]+=h;}
static void sha_init(sha256_ctx*c){static const u32 h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};int i;for(i=0;i<8;i++)c->h[i]=h[i];c->bits=0;c->used=0;}
static void sha_update(sha256_ctx*c,const u8*x,u32 n){c->bits+=(u64)n*8;while(n){u32 z=64-c->used,i;if(z>n)z=n;for(i=0;i<z;i++)c->buf[c->used+i]=x[i];c->used+=z;x+=z;n-=z;if(c->used==64){sha_block(c,c->buf);c->used=0;}}}
static void sha_final(sha256_ctx*c,u8 out[32]){int i;c->buf[c->used++]=0x80;if(c->used>56){while(c->used<64)c->buf[c->used++]=0;sha_block(c,c->buf);c->used=0;}while(c->used<56)c->buf[c->used++]=0;for(i=7;i>=0;i--)c->buf[c->used++]=(u8)(c->bits>>(8*i));sha_block(c,c->buf);for(i=0;i<8;i++){out[4*i]=(u8)(c->h[i]>>24);out[4*i+1]=(u8)(c->h[i]>>16);out[4*i+2]=(u8)(c->h[i]>>8);out[4*i+3]=(u8)c->h[i];}}

#define MAX_NODES 64
#define MAX_COMP 260
#define MAX_PATH 32768

typedef struct { HANDLE h; FILE_ID_INFO id; FILE_ATTRIBUTE_TAG_INFO tag; WCHAR component[MAX_COMP]; u32 is_dir; } chain_node;
typedef struct { chain_node nodes[MAX_NODES]; u32 count; DWORD volume_serial32; u64 volume_serial64; WCHAR fs_name[32]; } path_chain;
static path_chain KC,CC;
static WCHAR ARGA[MAX_PATH],ARGB[MAX_PATH];
static u8 IO_BUF[65536];

static u32 wlen(const WCHAR*s){u32 n=0;while(s&&s[n])n++;return n;}
static int wcmp(const WCHAR*a,const WCHAR*b){u32 i=0;while(a[i]&&b[i]&&a[i]==b[i])i++;return (int)a[i]-(int)b[i];}
static int wicmp_ascii(const WCHAR*a,const WCHAR*b){u32 i=0;for(;;i++){WCHAR x=a[i],y=b[i];if(x>='a'&&x<='z')x-=32;if(y>='a'&&y<='z')y-=32;if(x!=y)return (int)x-(int)y;if(!x)return 0;}}
static void wcopy(WCHAR*d,u32 cap,const WCHAR*s){u32 i=0;if(!cap)return;for(;i+1<cap&&s[i];i++)d[i]=s[i];d[i]=0;}
static int memeq16(const u8*a,const u8*b){int i;for(i=0;i<16;i++)if(a[i]!=b[i])return 0;return 1;}
static int nonzero16(const u8*a){int i;for(i=0;i<16;i++)if(a[i]!=0)return 1;return 0;}
static void memzero(void*p,u32 n){u8*x=(u8*)p;while(n--)*x++=0;}
void *memset(void *p,int v,SIZE_T n){u8*x=(u8*)p;while(n--)*x++=(u8)v;return p;}
void *memcpy(void *d,const void *s,SIZE_T n){u8*dd=(u8*)d;const u8*ss=(const u8*)s;while(n--)*dd++=*ss++;return d;}
static void write_ascii(HANDLE h,const char*s){DWORD n=0,w=0;while(s[n])n++;WriteFile(h,s,n,&w,0);}
static void write_u32(HANDLE h,u32 x){char b[16];int i=15;b[i--]=0;if(x==0){b[i--]='0';}else while(x&&i>=0){b[i--]=(char)('0'+x%10);x/=10;}write_ascii(h,b+i+1);}
static void write_u64(HANDLE h,u64 x){char b[32];int i=31;b[i--]=0;if(x==0){b[i--]='0';}else while(x&&i>=0){b[i--]=(char)('0'+(u32)(x%10));x/=10;}write_ascii(h,b+i+1);}
static void hex16(const u8 x[16],char out[33]){static const char H[]="0123456789abcdef";int i;for(i=0;i<16;i++){out[2*i]=H[x[i]>>4];out[2*i+1]=H[x[i]&15];}out[32]=0;}
static void hex_u64(u64 x,char out[17]){static const char H[]="0123456789abcdef";int i;for(i=15;i>=0;i--){out[i]=H[x&15];x>>=4;}out[16]=0;}
static void hex32(const u8 x[32],char out[65]){static const char H[]="0123456789abcdef";int i;for(i=0;i<32;i++){out[2*i]=H[x[i]>>4];out[2*i+1]=H[x[i]&15];}out[64]=0;}
static void stop(const char*msg,u32 code){HANDLE e=GetStdHandle(STD_ERROR_HANDLE);write_ascii(e,"STOP ");write_ascii(e,msg);write_ascii(e,"\r\n");ExitProcess(code?code:1);}
static void init_us(UNICODE_STRING*u,WCHAR*s){u32 n=wlen(s);if(n>32767)stop("COMPONENT_TOO_LONG",20);u->Length=(USHORT)(n*2);u->MaximumLength=u->Length;u->Buffer=s;}
static int same_id(const FILE_ID_INFO*a,const FILE_ID_INFO*b){return a->VolumeSerialNumber==b->VolumeSerialNumber && memeq16(a->FileId.Identifier,b->FileId.Identifier);}
static int bad_component(const WCHAR*s){u32 i;if(!s||!s[0])return 1;if((s[0]=='.'&&s[1]==0)||(s[0]=='.'&&s[1]=='.'&&s[2]==0))return 1;for(i=0;s[i];i++)if(s[i]=='\\'||s[i]=='/'||s[i]==':')return 1;return 0;}
static void inspect(HANDLE h,u32 want_dir,chain_node*out,WCHAR*component){u32 forbidden_cloud;memzero(out,(u32)sizeof(*out));out->h=h;out->is_dir=want_dir;wcopy(out->component,MAX_COMP,component);if(!GetFileInformationByHandleEx(h,FILE_ID_INFO_CLASS,&out->id,(DWORD)sizeof(out->id)))stop("FILE_ID_INFO",21);if(!nonzero16(out->id.FileId.Identifier))stop("ZERO_FILE_ID",23);if(!GetFileInformationByHandleEx(h,FILE_ATTRIBUTE_TAG_INFO_CLASS,&out->tag,(DWORD)sizeof(out->tag)))stop("FILE_ATTRIBUTE_TAG_INFO",22);if(out->tag.FileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)stop("REPARSE_COMPONENT",25);if(out->tag.ReparseTag!=0)stop("REPARSE_TAG",26);forbidden_cloud=FILE_ATTRIBUTE_OFFLINE|FILE_ATTRIBUTE_VIRTUAL|FILE_ATTRIBUTE_RECALL_ON_OPEN|FILE_ATTRIBUTE_PINNED|FILE_ATTRIBUTE_UNPINNED|FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS;if(out->tag.FileAttributes&forbidden_cloud)stop("OFFLINE_CLOUD_VIRTUAL",24);if(want_dir && !(out->tag.FileAttributes&FILE_ATTRIBUTE_DIRECTORY))stop("EXPECTED_DIRECTORY",27);if(!want_dir && (out->tag.FileAttributes&FILE_ATTRIBUTE_DIRECTORY))stop("EXPECTED_FILE",28);}
static HANDLE open_child(HANDLE parent,WCHAR*component,u32 is_dir){UNICODE_STRING us;OBJECT_ATTRIBUTES oa;IO_STATUS_BLOCK iosb;HANDLE h=0;NTSTATUS st;ACCESS_MASK access;ULONG share,opts;if(bad_component(component))stop("BAD_COMPONENT",30);init_us(&us,component);oa.Length=(ULONG)sizeof(oa);oa.RootDirectory=parent;oa.ObjectName=&us;oa.Attributes=OBJ_CASE_INSENSITIVE;oa.SecurityDescriptor=0;oa.SecurityQualityOfService=0;iosb.Status=0;iosb.Information=0;access=SYNCHRONIZE|FILE_READ_ATTRIBUTES|(is_dir?FILE_LIST_DIRECTORY:FILE_READ_DATA);share=FILE_SHARE_READ|(is_dir?FILE_SHARE_WRITE:0);opts=FILE_OPEN_REPARSE_POINT|FILE_SYNCHRONOUS_IO_NONALERT|(is_dir?FILE_DIRECTORY_FILE:FILE_NON_DIRECTORY_FILE);st=NtOpenFile(&h,access,&oa,&iosb,share,opts);if(!NT_SUCCESS(st))stop("NTOPEN_CHILD",31);return h;}
static HANDLE open_root(WCHAR*root){HANDLE h=CreateFileW(root,FILE_LIST_DIRECTORY|FILE_READ_ATTRIBUTES|SYNCHRONIZE,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OPEN_REPARSE_POINT,0);if(h==INVALID_HANDLE_VALUE)stop("OPEN_ROOT",32);return h;}
static void volume_check(HANDLE h,path_chain*c,const FILE_ID_INFO*id){WCHAR fs[32];DWORD serial=0,maxcomp=0,flags=0;if(!GetVolumeInformationByHandleW(h,0,0,&serial,&maxcomp,&flags,fs,32))stop("VOLUME_INFO",33);if(wicmp_ascii(fs,(WCHAR[]){'N','T','F','S',0})!=0)stop("NOT_NTFS",34);if(c->count==0){c->volume_serial32=serial;c->volume_serial64=id->VolumeSerialNumber;wcopy(c->fs_name,32,fs);}else{if(c->volume_serial32!=serial)stop("VOLUME_DRIFT32",35);if(c->volume_serial64!=id->VolumeSerialNumber)stop("VOLUME_DRIFT64",37);}}
static void chain_add(path_chain*c,HANDLE h,u32 is_dir,WCHAR*comp){if(c->count>=MAX_NODES)stop("CHAIN_TOO_LONG",36);inspect(h,is_dir,&c->nodes[c->count],comp);volume_check(h,c,&c->nodes[c->count].id);c->count++;}
static int split_abs(WCHAR*path,WCHAR parts[MAX_NODES][MAX_COMP],u32*n,WCHAR root[4]){u32 p=0,count=0,i,len;WCHAR d;if(!path||!path[0]||!path[1]||!path[2])return 0;d=path[0];if(!((d>='A'&&d<='Z')||(d>='a'&&d<='z')))return 0;if(path[1]!=':'||path[2]!='\\')return 0;if(!path[3])return 0;root[0]=d;root[1]=':';root[2]='\\';root[3]=0;p=3;while(path[p]){if(path[p]=='\\'||path[p]=='/')return 0;i=p;while(path[p]&&path[p]!='\\'){if(path[p]=='/')return 0;p++;}len=p-i;if(!len||len>=MAX_COMP||count>=MAX_NODES)return 0;{u32 j;for(j=0;j<len;j++)parts[count][j]=path[i+j];parts[count][len]=0;}if(bad_component(parts[count]))return 0;count++;if(path[p]=='\\'){p++;if(!path[p])return 0;}}*n=count;return count>0;}
static WCHAR PARTS[MAX_NODES][MAX_COMP];
static void build_chain(WCHAR*path,path_chain*c){WCHAR root[4];u32 n=0,i;HANDLE parent,child;memzero(c,(u32)sizeof(*c));if(!split_abs(path,PARTS,&n,root))stop("BAD_ABSOLUTE_PATH",40);parent=open_root(root);chain_add(c,parent,1,root);for(i=0;i<n;i++){u32 is_dir=(i+1<n);child=open_child(parent,PARTS[i],is_dir);chain_add(c,child,is_dir,PARTS[i]);parent=child;}}
static void revalidate(path_chain*c){u32 i;chain_node now;for(i=0;i<c->count;i++){inspect(c->nodes[i].h,c->nodes[i].is_dir,&now,c->nodes[i].component);if(!same_id(&now.id,&c->nodes[i].id))stop("FILE_ID_DRIFT",50);volume_check(c->nodes[i].h,c,&now.id);}}
static int hash_handle(HANDLE h,u8 out[32]){LARGE_INTEGER z;DWORD got;sha256_ctx c;z.QuadPart=0;if(!SetFilePointerEx(h,z,0,FILE_BEGIN))return 0;sha_init(&c);for(;;){got=0;if(!ReadFile(h,IO_BUF,(DWORD)sizeof(IO_BUF),&got,0))return 0;if(!got)break;sha_update(&c,IO_BUF,got);}sha_final(&c,out);if(!SetFilePointerEx(h,z,0,FILE_BEGIN))return 0;return 1;}
static void close_chain(path_chain*c){u32 i=c->count;while(i){i--;CloseHandle(c->nodes[i].h);}c->count=0;}

/* Strict command-line parser for exactly: exe --qualify-paths <kernel> <wslconfig>.
 * An argument may be wholly quoted to carry spaces. Embedded/malformed quotes and
 * all trailing arguments are rejected fail closed. */
static int next_arg(WCHAR**pp,WCHAR*out,u32 cap){WCHAR*p=*pp;u32 n=0;int quoted=0,closed=0;while(*p==' '||*p=='\t')p++;if(!*p){*pp=p;return 0;}if(*p=='"'){quoted=1;p++;}while(*p){if(quoted){if(*p=='"'){closed=1;p++;break;}}else{if(*p=='"')return -2;if(*p==' '||*p=='\t')break;}if(n+1>=cap)return -1;out[n++]=*p++;}if(quoted&&!closed)return -2;if(quoted&&*p&&*p!=' '&&*p!='\t')return -2;out[n]=0;while(*p==' '||*p=='\t')p++;*pp=p;return n?1:-2;}
static WCHAR ARG0[1024],ARG1[128],ARGX[2];
static int parse_cli(void){WCHAR*p=GetCommandLineW();if(next_arg(&p,ARG0,1024)<=0)return 0;if(next_arg(&p,ARG1,128)<=0)return 0;if(wcmp(ARG1,(WCHAR[]){'-','-','q','u','a','l','i','f','y','-','p','a','t','h','s',0})!=0)return 0;if(next_arg(&p,ARGA,MAX_PATH)<=0)return 0;if(next_arg(&p,ARGB,MAX_PATH)<=0)return 0;if(next_arg(&p,ARGX,2)!=0)return 0;return 1;}

static void write_chain_json(HANDLE o,const path_chain*c){u32 i;char idhex[33],volhex[17];write_ascii(o,"[");for(i=0;i<c->count;i++){if(i)write_ascii(o,",");hex16(c->nodes[i].id.FileId.Identifier,idhex);hex_u64(c->nodes[i].id.VolumeSerialNumber,volhex);write_ascii(o,"{\"index\":");write_u32(o,i);write_ascii(o,",\"file_id\":\"");write_ascii(o,idhex);write_ascii(o,"\",\"volume_serial64_hex\":\"");write_ascii(o,volhex);write_ascii(o,"\",\"volume_serial32\":");write_u32(o,c->volume_serial32);write_ascii(o,",\"filesystem\":\"NTFS\",\"file_attributes\":");write_u32(o,c->nodes[i].tag.FileAttributes);write_ascii(o,",\"reparse_tag\":");write_u32(o,c->nodes[i].tag.ReparseTag);write_ascii(o,",\"is_directory\":");write_ascii(o,c->nodes[i].is_dir?"true":"false");write_ascii(o,"}");}write_ascii(o,"]");}
void gateq_entry(void){u8 kh[32],ch[32];char hx[65];HANDLE o=GetStdHandle(STD_OUTPUT_HANDLE);if(!parse_cli())stop("USAGE",64);build_chain(ARGA,&KC);build_chain(ARGB,&CC);revalidate(&KC);revalidate(&CC);if(!hash_handle(KC.nodes[KC.count-1].h,kh)||!hash_handle(CC.nodes[CC.count-1].h,ch))stop("HASH",60);write_ascii(o,"{\"schema\":\"TSUCHIMARU_WINDOWS_PATH_CHAIN_QUAL_V1\",\"status\":\"PASS\",\"kernel_sha256\":\"");hex32(kh,hx);write_ascii(o,hx);write_ascii(o,"\",\"config_sha256\":\"");hex32(ch,hx);write_ascii(o,hx);write_ascii(o,"\",\"kernel_nodes\":");write_u32(o,KC.count);write_ascii(o,",\"config_nodes\":");write_u32(o,CC.count);write_ascii(o,",\"kernel_chain\":");write_chain_json(o,&KC);write_ascii(o,",\"config_chain\":");write_chain_json(o,&CC);write_ascii(o,"}\r\n");close_chain(&KC);close_chain(&CC);ExitProcess(0);}
