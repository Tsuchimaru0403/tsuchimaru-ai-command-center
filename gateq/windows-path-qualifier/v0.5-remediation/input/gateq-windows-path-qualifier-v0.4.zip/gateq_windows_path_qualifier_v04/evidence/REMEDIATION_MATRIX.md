# Gate Q Windows Path Qualifier v0.4 — v0.3 Fresh Audit Remediation Matrix

Prior Fresh Static Audit result for v0.3: FAIL — CRITICAL 0 / MAJOR 4 / MINOR 2 / NOTE 2.

| Finding | v0.4 remediation | Static candidate state |
|---|---|---|
| F-01 MAJOR — CLI allowlist | Strict whole-argument quoting; malformed/unclosed/embedded quotes rejected; fifth/trailing argument rejected. | REMEDIATED / pending Fresh Re-Audit |
| F-02 MAJOR — zero FileId | Every root/descendant `FILE_ID_INFO.FileId` must contain at least one nonzero byte. | REMEDIATED / pending Fresh Re-Audit |
| F-03 MAJOR — volume identity | Root records 32-bit `GetVolumeInformationByHandleW` serial and 64-bit `FILE_ID_INFO.VolumeSerialNumber`; every node and revalidation must equal both root identities. | REMEDIATED / pending Fresh Re-Audit |
| F-04 MAJOR — offline/cloud/virtualized | Rejects `OFFLINE`, `VIRTUAL`, `RECALL_ON_OPEN`, `PINNED`, `UNPINNED`, `RECALL_ON_DATA_ACCESS` in addition to all reparse state. | REMEDIATED STATICALLY / actual Windows behavior still requires host qualification |
| F-05 MINOR — drive letter | Absolute path drive designator restricted to ASCII `A-Z` / `a-z`; forward slash, duplicate separators and trailing separator rejected. | REMEDIATED / pending Fresh Re-Audit |
| F-06 MINOR — final pointer reset | Final `SetFilePointerEx(..., FILE_BEGIN)` failure makes `hash_handle()` fail and prevents PASS. | REMEDIATED / pending Fresh Re-Audit |
| F-07 NOTE — A/B execution evidence | A and B rebuilt from fresh directories with separate invocations; exact xtrace logs included; Python 3.13.5 and absolute generation-tool paths are bound. | EVIDENCE ADDED / pending Fresh Re-Audit |
| F-08 NOTE — output identity evidence | PASS JSON now includes per-node FileId, root-bound 32/64-bit volume identities, filesystem, attributes, reparse tag and type. | EVIDENCE ENRICHED / pending Fresh Re-Audit |

This remediation does not execute the PE on Windows and does not close `Q18-WINDOWS-HOST-01`. It does not implement the full Runtime boot witness.
